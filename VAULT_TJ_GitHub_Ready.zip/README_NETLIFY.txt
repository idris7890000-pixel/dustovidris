VAULT TJ — Smooth Scroll Fix

Deploy this package to Netlify by uploading the contents of this ZIP together: index.html, _headers, and assets/.
Do not extract only index.html: the WebP files in assets/ are required.

Main fixes: on-demand small thumbnails, no pre-created local video players, no eager full-size server photo requests, off-screen card rendering optimization, and mobile blur reduction.
